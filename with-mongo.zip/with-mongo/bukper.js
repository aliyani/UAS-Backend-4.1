const express = require("express");
const routerBukper = express.Router()

let bukper = [{nomor:'01', namabuku:'akuntansi', tanggalpinjam:'10-05-2021', namapeminjam:'aliya',create:new Date()},
                 {nomor:'02', namabuku:'geografi', tanggalpinjam:'12-03-2021', namapeminjam:'dila',create:new Date()},
                 {nomor:'03', namabuku:'fisika', tanggalpinjam:'1306-2021', namapeminjam:'nana',create:new Date()},
                ]

const cari = (arrData,size) =>{
    ketemu = -1
    indeks = 0
    while(ketemu == -1 && indeks < arrData.length){
        if(arrData[indeks].size == size){
            ketemu = indeks
            return indeks
        }
        indeks++
    }
    return -1
}

routerBukper.route('/bukper')
    .get( (req,res)=>{
        res.json(bukper)
    })

    .post((req,res)=>{
        //Ambil data request dari front end
        const newItem = {
            nomor : req.body.nomor,
            namabuku : req.body.namabuku,
            tanggalpinjam : req.body.tanggalpinjam,
            namapeminjam : req.body.namapeminjam
        }
        bukper.push(newItem)
        res.status(201).json(newItem)
    })

routerBukper.route('/bukper/:nomor')
    .put((req,res)=>{
       nomor = req.params.nomor
        indeks = cari(bukper,nomor)
        if(indeks != -1){
            bukper[indeks].nomor = nomor
            bukper[indeks].namabuku = req.body.namabuku
            bukper[indeks].tanggalpinjam = req.body.tanggalpinjam
            bukper[indeks].namapeminjam = req.body.namapeminjam

            res.json(bukper[indeks])
        }
        else{
            res.send('Data bukper tidak ditemukan')
        }
        
    })

    .delete((req,res)=>{
        nomor = req.params.nomor
        indeks = cari(bukper,nomor)
        if(indeks != -1){
            bukper.splice(indeks,1)
            res.send('Bukper dengan nomor ' + nomor + ' telah dihapus')
        }
        else
        {
            res.send('Data bukper tidak ditemukan')
        }
        
    })

    .get((req,res)=>{
        nomor = req.params.nomor
        indeks = cari(bukper,nomor)
        if(indeks != -1){
            const dataBukper = {nomor:bukper[indeks].nomor,
                                   namabuku:bukper[indeks].namabuku,
                                   tanggalpinjam:bukper[indeks].tanggalpinjam,
                                   namapeminjam:bukper[indeks].namapeminjam
                                  }
            res.json(dataBukper)
        }
        else{
            res.send('Bukper dengan nomor : ' +nomor + ' tidak ditemukan')
        }
        
    })

routerBukper.get('/bukper/:namabuku/:terpopuler', (req,res)=>{
    const namabuku = req.params.namabuku
    const terpopuler = req.params.terpopuler
    res.send('Bukper namabuku : ' + namabuku + ' terpopuler : ' + terpopuler)
})

module.exports = routerBukper