const mongoose = require('mongoose')

const bpEmbeddedSchema = new mongoose.Schema({
    nomor:{
        required: true,
        type: String
    },
    namabuku:{
        required: true,
        type: String
    },
    tanggalpinjam:{
        required: true,
        type: String
    },
    namapeminjam:{
        required: true,
        type: String
    },
    produk: [{
        kode : String,
        jenisbuku : String,
        kualitas : String,
        lamapeminjaman : String,
        batasbuku : String
    }]
})

module.exports = mongoose.model('bukper', bpEmbeddedSchema,'bukper')