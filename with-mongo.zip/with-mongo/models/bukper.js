const mongoose = require('mongoose')

const bpSchema = new mongoose.Schema({
    nomor : {
        require : true,
        type : String
    },
    namabuku : String,
    tanggalpinjam : String,
    namapeminjam : String,
})

module.exports = mongoose.model('bukper', bpSchema,'bukper')