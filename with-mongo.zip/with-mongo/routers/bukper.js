const express = require("express");
const routerBukper = express.Router()
const controllerBukper = require('../controllers/bukper')

routerBukper.route('/bukper')
    .get(controllerBukper.getBukper)
    .post(controllerBukper.insert)

routerBukper.route('/bukper/:nomor')
    .put(controllerBukper.update)
    .delete(controllerBukper.delete)
    .get(controllerBukper.getSepatuByMerk)

routerBukper.route('/bukper/produk/:nomor')
    .get(controllerBukper.getProdukByNomor)
    .put(controllerBukper.insertProduk)

module.exports = routerBukper