const Bukper = require('../models/bpEmbedded')


module.exports = {
    insert : async (req,res)=>{
        //Ambil data request dari front end
        const data = new Bukper({
            nomor : req.body.nomor,
            namabuku : req.body.namabuku,
            tanggalpinjam : req.body.tanggalpinjam,
            namapeminjam : req.body.namapeminjam,
        })
        try {
            const dataToSave = await data.save()
            res.status(200).json(dataToSave)
        } catch (error) {
            res.status(400).json({message:error.message})
        }
    },

    insertProduk: async (req,res)=>{
        const nomor = req.params.nomor

        try{
            await Bukper.updateOne(
                {"nomor":nomor},
                {
                    $push:{
                        "produk":{
                            "kode": req.body.kode,
                            "jenisbuku": req.body.jenisbuku,
                            "kualitas":req.body.kualitas,
                            'lamapeminjaman':req.body.lamapeminjaman,
                            "batasbuku": req.body.batasbuku,
                        }
                    }
                })
            res.send('Produk telah di simpan')
            } catch (error){
                res.status(409).json({message: error.message})
            }
    },
    
    getBukper : async (req,res)=>{
        try {
            const result = await Sepatu.find()
            res.status(200).json(result)
        } catch (error) {
            res.status(404).json({message : error.message})
        }
    },
    getBukperByNomor : async (req,res)=>{
         const nomor = req.params.nomor
         try {
             const result = await Bukper.find().where('nomor').equals(nomor)
             res.json(result)
         } catch (error) {
             res.status(500).json({message: error.message})
         }
    },

    getBukperByNomor : async (req,res) => {
        const nomor = req.params.nomor;
        try{
            const result = await Bukper.findOne({"nomor": nomor}, {"_id":0,"produk": 1})
            /* let res2 =[];
            for (let i = 0; i < result.lenght i++){
                res2.push(result[i])
            }*/
            res.json(result)
        } catch (error){
            res.status(500).json({ message : error.message})
        }
    },
    update : async (req,res)=>{
        const filter = {nomor : req.params.nomor}
        const updatedData = {
            namabuku : req.body.namabuku,
            tanggalpinjam : req.body.tanggalpinjam,
            namapeminjam : req.body.namapeminjam
        }
        try {
            let result = await Bukper.updateOne(filter,updatedData)
            res.send('Data telah terupdate')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    },

    delete : async (req,res)=>{
        const filter = {nomor : req.params.nomor}
        try {
            await Bukper.deleteOne(filter);
            res.send('Data telah terhapus')
        } catch (error) {
            res.status(409).json({message : error.message})
        }
        
    }
}